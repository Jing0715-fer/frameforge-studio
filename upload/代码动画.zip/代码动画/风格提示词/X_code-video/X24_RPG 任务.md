# X24 RPG 任务（RPG quest）

- 分类：X code-video · code-video
- 适合：学习像做任务

## 风格提示词

# Style: 16-bit RPG quest

A clip that reads like a cutscene lifted from a 16-bit console RPG (SNES/Game Boy Advance era): a fixed-camera pixel-art diorama, a JRPG dialogue box with typewriter text, a "quest log" stat panel, a sword-and-slime battle vignette, a radial-burst level-up screen, and a loot-pickup card, bookended by a night title card and a sunset "quest clear" card. A thin scanline texture sits over every frame, and a chiptune-style pulsing melody drives the pacing. The overall feeling is nostalgic, toy-like, and gamified — factual/data content (benchmark scores, price changes) is translated one-to-one into RPG game-feel (quest completion bars, "+EXP" pickups, loot cards, stat increases).

## Signature
| Item | On screen |
|---|---|
| Ground truth: fixed low-res pixel-art dioramas | Every scene is a static illustrated background (starry night skyline with moon and castle silhouette; daytime village with houses/trees/road; dungeon brick corridor with wall torches; sunset hillside) rendered in blocky, low-detail pixel art with no camera pan/zoom |
| Palette: deep indigo night + warm amber accents | Night/dungeon backdrops sit in `#0C0A22`–`#1B1545`–`#371D5A` indigo-violet; warm points of light in `#E6B85A` (window glow) and `#FDF2D2` (torch flame); daytime scene uses `#5FB3FC` sky and `#54A048` grass; sunset ending blends `#271A50` → `#C65952` → `#F29F6B` |
| UI chrome: rounded steel-bordered dialogue/panel boxes | Navy-blue fill (`#283267`/`#314292`) boxes with a light-gray beveled border, a tabbed name-plate in the corner (e.g. a small pill reading a speaker name), used for both dialogue and stat panels |
| Progress bars as game meters | Horizontal bordered bars with a solid orange-terracotta fill (`#BE674C`) over a dark navy track, a white tick mark marking a "previous score" reference point, a percentage readout, and a rotated red/gold "완료!" (complete) stamp ribbon on finish |
| Blocky pixel typography with drop shadow | All text (titles, dialogue, UI labels) uses a chunky, uniform-width pixel font with a hard 1-tone drop shadow; headline words (e.g. "LEVEL UP!") animate in as individually offset/bouncing letters |
| Cross-shaped sparkle/particle bursts | Small "+"-shaped white/gold sparkles drift and twinkle in night skies, radial-burst screens, and loot-glow beams; green/white square particles burst on "hit" or "+EXP" moments |
| Global scanline overlay | A faint, constant horizontal line texture (CRT-style) is visible across every frame, in every scene, at every brightness level |
| Loot/reward cards with struck-through old values | Item-pickup notifications show an old value with a red strikethrough next to a new value in green, styled like an RPG equipment-acquired popup, with a small gold spotlight beam and glowing ring/key icon |

## Direction
Render a fixed-camera, low-resolution pixel-art RPG cutscene in distinct static "cards" cut together with hard black-frame transitions (occasional flash or halftone-dissolve texture on the cut, never a crossfade). Use a blocky pixel font with a flat drop shadow for all text, typewriter-reveal dialogue lines inside a rounded, steel-bordered navy dialogue box with a small tabbed name-plate in the corner. Palette: deep indigo-to-violet night skies with warm amber points of light, a bright daytime sky-blue/grass-green village alternative, and a warm sunset gradient (purple → coral → peach) for a bookend opening/closing card; keep every scene otherwise low-saturation and flat-shaded. Apply a constant, subtle horizontal scanline texture over the whole frame. Translate any factual/quantitative content (scores, comparisons, price or performance changes) into game mechanics: bordered progress-meter bars with a reference tick mark and a percentage label, a rotating "complete!" stamp ribbon on milestones, floating "+"-shaped sparkle particles and score-pop text on gains, and RPG loot-card popups (old value struck through in red, new value in green) for improvements. Include at least one radial-burst "level up" card with a character silhouette centered in rotating light rays and stat lines animating in one by one with up/down arrows. Score it with a continuously pulsing chiptune-style melody that holds a steady mid-level loudness through the first two-thirds, dips into a brief near-silent beat at a dramatic cut, then builds louder toward a final climax before cutting to silence on the last frame — no fade-outs anywhere in picture or sound.
